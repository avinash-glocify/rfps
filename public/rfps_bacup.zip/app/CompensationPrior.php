<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CompensationPrior extends Model
{
    protected $table = 'rfps_compensation_prior';

    
 
	public $timestamps = false;
    
}
