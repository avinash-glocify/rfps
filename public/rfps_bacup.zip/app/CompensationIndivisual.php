<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CompensationIndivisual extends Model
{
    protected $table = 'rfps_compensation_indivisual_included';

    
 
	public $timestamps = false;
    
}
