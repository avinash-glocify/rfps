<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CompensationPremiumstate extends Model
{
    protected $table = 'rfps_compensation_premium_state';

    
 
	public $timestamps = false;
    
}
