<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Rates extends Model
{
    protected $table = 'rfps_manual_rates';

 
	public $timestamps = false;
    
}
