<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CompensationRating extends Model
{
    protected $table = 'rfps_compensation_rating';

    
 
	public $timestamps = false;
    
}
