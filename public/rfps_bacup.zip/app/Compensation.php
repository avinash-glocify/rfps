<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Compensation extends Model
{
    protected $table = 'rfps_workers_compensation';

    
 
	public $timestamps = false;
    
}
