<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CompensationContact extends Model
{
    protected $table = 'rfps_workers_compensation_contact';

    
 
	public $timestamps = false;
    
}
