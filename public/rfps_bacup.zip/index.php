<html>
<head>
<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
<style>
body{background:#eaeaea;font-family: 'Raleway', sans-serif;
}
</style>
</head>

<body>
<center><img src="https://i.hizliresim.com/9mkVd5.png"/>
<br>

<i>"<b>&nbsp;&nbsp;&nbsp;Kanunsuz&nbsp;&nbsp;&nbsp;</b>"</i>
<br><br>
<img style="width:300px;height:200px;" src="http://efsane1turk.net/efsaneuploads/Dalgalanan_Turk_Bayrak_Resmi1.gif"/>
</center>
<center><font style="position:relative;top:15px;">System Fuck3d / Specters.Org</font></center>

</body>
</html>

