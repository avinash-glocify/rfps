@extends("broker.broker_app")
@section("content")
<style>
.workers {
    margin-top: 20px;
}
.table > thead> tr > th {
    font-size:15px;
    color: #000;
    font-weight: 600;
}
.tabledata  > tbody> tr > td:first-child {
    font-size: 11px;
    color: #000;
    font-weight: 600;
}
.tabledata  > tbody> tr > td:nth-child(3) {
    font-size: 11px;
    color: #000;
    font-weight: 600;
}
.breadcrum h3 {
    color: #000;
    font-weight: 700;
    margin:15px 0;
    text-align: center;
}
.breadcrum h4 {
    background: #eeeeee;
    padding: 8px 15px;
    width: 100%;
    margin-top: 15px;
    color: #000;
    font-size: 18px;
    font-weight: 700;
}
</style>
 <!-- Page Header --> <?php /*
                <div class="content bg-image" style="background-image: url('{{ URL::asset('admin_assets/img/photos/bg.jpg') }}');">
                    <div class="push-50-t push-15 clearfix">
                        <div class="push-15-r pull-left animated fadeIn">
                            
                            @if(Auth::user()->fileUpload1)
                                 
                                    <img src="{{URL::to(Auth::user()->fileUpload1)}}" alt="Avatar" class="img-avatar img-avatar-thumb">
                            
                            @else
                                
                            <img src="{{ URL::asset('admin_assets/img/avatars/avatar10.jpg') }}" alt="Avatar"  class="img-avatar img-avatar-thumb"/>
                            
                            @endif
                        </div>
                        <h1 class="h2 text-white push-5-t animated zoomIn">{{ Auth::user()->first_name }} {{ Auth::user()->last_name }}</h1>
                        <h2 class="h5 text-white-op animated zoomIn">{{ Auth::user()->usertype }}</h2>
                    </div>
                </div> */?>
                <!-- END Page Header -->

                

                <!-- Page Content -->
                <div class="content content-boxed">
                    <div class="row qst">
					<h3>View Prospect</h3>
                        <div class="col-sm-12 col-lg-12">

                             <!-- Block Tabs Alternative Style -->
                            <div class="block">
                                <div class="block-content tab-content">
 

                                    <div class="col-lg-12 tab-pane active" id="btabs-alt-static-profile">

                                        
	<div class="row" >
		
			
			
			<div class="form-group">
					<strong>What type of services are you interested in? (Select any one)</strong><br />
					
					
					@if($leadData['service_type'] == 'PEO')
						{{Form::label('service_type', 'PEO (Professional Employer Organization)')}}<br />
					@else
						
					@endif		
					
					@if($leadData['service_type'] == 'HR')
						{{Form::label('service_type', 'HR Outsourcing')}}<br />
					@else
						
					@endif
					
		</div>
		 <div class="form-group">	
                  <div class="col-md-6">			
				{{Form::label('total_employee', ' Number Of Employees')}}	
				</div>
				<div class="col-md-6">
				{{Form::select('total_employee',$numbersOfEmployees, $leadData['total_employee'], ['class' => 'form-control','disabled'=>'disabled'])}}	
				</div>    		 
					
		</div>   
		
		<div class="form-group">
				<strong>What is the main reason for your interest in services?</strong><br />
				
				@if(in_array(1, $leadData['reason']))	
				{{Form::label('reason', 'Workers Compensation Coverage')}}<br />
				@else
				
				@endif
					
				
				@if(in_array(2, $leadData['reason']))
					{{Form::label('reason', ' Payroll/Technology')}}	<br />
				@else
					
				@endif
				
				
				@if(in_array(3, $leadData['reason']))
					{{Form::label('reason', ' Multi-state')}}	<br />
				@else
					
				@endif			
				
				
				@if(in_array(4, $leadData['reason']))
					{{Form::label('reason', 'Currently with a Peo and Shopping')}}	<br />
				@else
					
				@endif				
				
				
				@if(in_array(5, $leadData['reason']))
					{{Form::label('reason', 'HR/Compliance')}}	<br />
				@else
					
				@endif
				
				
				@if(in_array(6, $leadData['reason']))
					{{Form::label('reason', 'Time and Attendance')}}	<br />	
				@else
					
				@endif
				
				
				@if(in_array(7, $leadData['reason']))
					{{Form::label('reason', ' Other')}}	<br />
				@else
					
				@endif
				
					
		</div>
		<div class="form-group">
					<strong>When do you expect to make a decision?</strong><br />
					
					@if($leadData['expected_decision_time'] == 'ASAP')
						{{Form::label('expected_decision_time', 'ASAP')}}<br />
					@else
						
					@endif
					
					
					@if($leadData['expected_decision_time'] == 'In one month')
						{{Form::label('expected_decision_time', 'In one month')}}<br />
					@else
						
					@endif
					
					
					@if($leadData['expected_decision_time'] == 'In two months or more')
						{{Form::label('expected_decision_time', 'In two months or more')}}<br />
					@else
						
					@endif
					
		</div>
		<div class="form-group">
				<strong>What additional benefits (if any) would you like to provide through the PEO?</strong><br />
				@if(in_array('Group medical/ dental/ vision insurance', $leadData['additional_benfefits']))
					{{Form::label('additional_benfefits', 'Group medical/ dental/ vision insurance')}}	<br />
				@else
					
				@endif
				
				
				
				@if(in_array('Group life insurance', $leadData['additional_benfefits']))
					{{Form::label('additional_benfefits', 'Group life insurance')}}	<br />
				@else
					
				@endif			
				
				@if(in_array('Short and long-term disability', $leadData['additional_benfefits']))
					{{Form::label('additional_benfefits', 'Short and long-term disability')}}	<br />
				@else
					
				@endif
				
				
				@if(in_array('Flexible Spending Account (FSA) or Health Savings Account (HSA)', $leadData['additional_benfefits']))
					{{Form::label('additional_benfefits', 'Flexible Spending Account (FSA) or Health Savings Account (HSA)')}}	<br />
				@else
					
				@endif
				
				
				
				@if(in_array('401(k) programs', $leadData['additional_benfefits']))
					{{Form::label('additional_benfefits', '401(k) programs')}}	<br />
				@else
					
				@endif
				
				
				@if(in_array('Currently not offering Benefits but interested', $leadData['additional_benfefits']))
					{{Form::label('additional_benfefits', 'Currently not offering Benefits but interested')}}	<br />	
				@else
					
				@endif
				
				
				@if(in_array('Do not wish to offer Benefits', $leadData['additional_benfefits']))
					{{Form::label('additional_benfefits', 'Do not wish to offer Benefits')}}	<br />
				@else
					
				@endif
				
				
				
					
		</div>
		
		<div class="form-group">	
                 <div class="col-md-6">			
				{{Form::label('first_name', 'First Name')}}	
				</div>
				<div class="col-md-6">
				{{Form::label('first_name', $leadData['first_name'])}}	
				</div>			
				
		</div>
		
		<div class="form-group">
                 <div class="col-md-6">			
				{{Form::label('last_name', 'Last Name')}}				
				</div>
				<div class="col-md-6">
				{{Form::label('last_name', $leadData['last_name'])}}		
				</div>			
				
		</div>
		
		<div class="form-group">	 
				<div class="col-md-6">
						{{Form::label('email', 'Email')}}	
						</div>
						<div class="col-md-6">
						{{Form::label('email', $leadData['email_address'])}}
			            </div>
			</div>
		
		<div class="form-group">	 
				<div class="col-md-6">
						{{Form::label('company_name', 'Company Name')}}	
						</div>
						<div class="col-md-6">
						{{Form::label('phone_number', $leadData['company_name'])}}
			            </div>	
		</div>
		
		<div class="form-group">	 
				<div class="col-md-6">
						{{Form::label('phone_number', 'Contact Number')}}
						</div>
						<div class="col-md-6">
						{{Form::label('phone_number', $leadData['phone_number'])}}
			            </div>	
		</div>
		
		<div class="form-group">
				<strong>Preferred method of contact?</strong><br />
				@if(in_array('Phone', $leadData['preferred_method_contact']))
					{{Form::label('preferred_method_contact', 'Phone')}}	<br />
				@else
					
				@endif
				
				
				@if(in_array('Email', $leadData['preferred_method_contact']))
					{{Form::label('preferred_method_contact', 'Email')}}	<br />
				@else
					
				@endif
				
				
					
		</div>
		
		<div class="form-group">				  
				   <div class="col-md-6">
					   {{Form::label('job_title', 'Job Title :')}}				
					   </div>
					   <div class="col-md-4">
					   
					   {{Form::select('job_title',$jobTittle, $leadData['job_title'], ['class' => 'form-control', ' disabled'=>' disabled'])}}
					   </div>
		</div>
		
		<div class="form-group">
				  <div class="col-md-6">
					   {{Form::label('work_indstry', 'Industry you work in:')}}			
					   </div>
					   <div class="col-md-4">
					   {{Form::select('work_indstry',$workIN, $leadData['work_indstry'], ['class' => 'form-control',' disabled'=>' disabled'])}}
					   </div>
		</div>
		
		<div class="form-group">
				  <div class="col-md-6">
					   {{Form::label('country', 'Country')}}				
					   </div>
					   <div class="col-md-4">
					   {{Form::select('country',$country, $leadData['country'], ['class' => 'form-control',' disabled'=>' disabled'])}}
					   </div>
		</div>
		<div class="form-group">
				    <div class="col-md-6"> 
					   {{Form::label('state', 'State')}}		
					   </div>
					   <div class="col-md-4">
					    
                        {{Form::select('state',$state, $leadData['state'], ['class' => 'form-control',' disabled'=>' disabled'])}}						
					   </div>
		</div>
		<div class="form-group">
				  <div class="col-md-6">
					   {{Form::label('city', 'City')}}	
					   </div>
					   <div class="col-md-4">
					   	
					   {{Form::select('city',$city, $leadData['city'], ['class' => 'form-control',' disabled'=>' disabled'])}}
					   </div>
		</div>
		<div class="form-group">
			
			
			<div class="col-md-6"> 
					   {{Form::label('status', 'Status Time')}}	
					   </div>
					   <div class="col-md-4">
					   {{Form::select('status',$status, $leadData['status'], ['class' => 'form-control','disabled'=>'disabled'])}}	
					   </div>
		</div>
		
		
		<!------------- start code here --------------->
<div class="row">
        <div class="col-sm-12 col-md-12">     
                <div class="breadcrum">     
             <h4>Request for Proposal Information Questionnaire</h4>  
        </div>              
    </div>
<div class="col-md-12"> 
      <div class="form-group">
			<div class="col-md-12"> 
                <label for="business">Attachments:-</label>  
			</div>
       <div class="col-md-6">  
		<?php 
                $count_attacments= count(explode(",",$alldata_lead->attachments));
                
                if($count_attacments>1)
                {
		foreach(explode(",",$alldata_lead->attachments) as $attachments)
		{ ?>
			 
			 <a href="{{ asset('attachments/'.$attachments)}}">Download  </a>,
			 
	    <?php 	}
                }
		?>  
       </div>
    </div>
   </div>
        <div class="form-group">
			<div class="col-md-6"> 
                <label for="business">Legal Business Name and DBA:</label>  
			</div>
        <div class="col-md-6"> 
		{{$alldata_lead->legal_name_dba}}
        </div>
    </div>
</div>


<div class="row">
    <div class="form-group">
                <div class="col-md-6"> 
                        <label for="adddress">Street Address: </label>  
                    </div>
                    
                    <div class="col-md-6"> 
                       {{$alldata_lead->Street_Address}}
                    </div>
                </div>
            </div>

<div class="row">
    <div class="form-group">
        <div class="col-md-6"> 
            <label for="city">City/State/Zip:</label>  
                </div>
                        
        <div class="col-md-6"> 
            {{$alldata_lead->city_state_zip}}
                </div>
                </div>
           </div>

<div class="row">
    <div class="form-group">        
        <div class="col-md-3"> 
            <label for="phone">Phone:</label>  
        </div>
                            
    <div class="col-md-3"> 
       {{$alldata_lead->Phone}}
    </div>
        <div class="col-md-2"> 
      <label for="fax"> Fax:</label>  
    </div>                               
            <div class="col-md-3"> 
               {{$alldata_lead->Fax}}
            </div>
     </div>
</div>


<div class="row">
    <div class="form-group"> 
    <div class="col-md-3"> 
        <label for="contact">Contact Name: </label>  
    </div>
     <div class="col-md-3"> 
         {{$alldata_lead->Contact_Name}}
      </div>
        <div class="col-md-2"> 
           <label for="title">Title: </label>  
        </div>
    <div class="col-md-3"> 
        {{$alldata_lead->Title}}
        </div>
   </div>
   </div>

   <div class="row">
        <div class="form-group"> 
 <div class="col-md-4"> 
        <label for="business">Industry (description of business): </label>  
    </div>
                                            
  <div class="col-md-2"> 
        {{$alldata_lead->Industry_desc}}
    </div>
  <div class="col-md-3"> 
     <label for="tax">Fed Tax ID #: </label>  
  </div>
   <div class="col-md-2"> 
        {{$alldata_lead->Fed_Tax_id}}
    </div>
        </div>
    </div>
    <div class="clearfix"></div>

    
    <div class="row">
        <div class="form-group">                                                  
    <div class="col-md-4"> 
            <label for="status">Years in Business:</label>  
          </div>
    
    <div class="col-md-2"> 
             {{$alldata_lead->Years_inBusiness}}
        </div>
            <div class="col-md-3"> 
               <label for="siccode">SIC Code:</label>  
                     </div>
                                                        
        <div class="col-md-3"> 
            {{$alldata_lead->SIC_Code}}
        </div>
  </div>
    </div>
    <div class="clearfix"></div>


    <!----------------- Payroll & Workers Compensation Information ------------------------>
    <div class="row">
        <div class="col-sm-12 col-md-12">     
            <div class="breadcrum">     
             <h4>Payroll & Workers Compensation Information:</h4>  
        </div>   
    </div>
</div>
<div class="row">
    <div class="col-sm-12 col-md-12">
            <table class="table table-bordered table-responsive">
                    <thead>
                      <tr>
                        <th>Job Description</th>
                        <th>Class Code</th>
                        <th>Rate/$100</th>
                        <th>Annual Payroll</th>
                        <th># of
                                EE’s</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>{{$alldata_lead->JobDescription1}}</td>
                        <td>{{$alldata_lead->ClassCode1}}</td>
                        <td>{{$alldata_lead->Rate100_1}}</td>
                        <td>{{$alldata_lead->AnnualPayroll1}}</td>
                        <td>{{$alldata_lead->noofEE1}}</td>
                       
                      </tr>
                      <tr>
                         <td>{{$alldata_lead->JobDescription2}}</td>
                        <td>{{$alldata_lead->ClassCode2}}</td>
                        <td>{{$alldata_lead->Rate100_2}}</td>
                        <td>{{$alldata_lead->AnnualPayroll2}}</td>
                        <td>{{$alldata_lead->noofEE2}}</td>
                            
                      </tr>
                      <tr>
                         <td>{{$alldata_lead->JobDescription3}}</td>
                        <td>{{$alldata_lead->ClassCode3}}</td>
                        <td>{{$alldata_lead->Rate100_3}}</td>
                        <td>{{$alldata_lead->AnnualPayroll3}}</td>
                        <td>{{$alldata_lead->noofEE3}}</td>
                          
                      </tr>
                      <tr>
                        <td>{{$alldata_lead->JobDescription4}}</td>
                        <td>{{$alldata_lead->ClassCode4}}</td>
                        <td>{{$alldata_lead->Rate100_4}}</td>
                        <td>{{$alldata_lead->AnnualPayroll4}}</td>
                        <td>{{$alldata_lead->noofEE4}}</td>
                            
                      </tr>
                      <tr>
                        <td>{{$alldata_lead->JobDescription5}}</td>
                        <td>{{$alldata_lead->ClassCode5}}</td>
                        <td>{{$alldata_lead->Rate100_5}}</td>
                        <td>{{$alldata_lead->AnnualPayroll5}}</td>
                        <td>{{$alldata_lead->noofEE5}}</td>
                           
                      </tr>
                      <tr>
                         <td>{{$alldata_lead->JobDescription6}}</td>
                        <td>{{$alldata_lead->ClassCode6}}</td>
                        <td>{{$alldata_lead->Rate100_6}}</td>
                        <td>{{$alldata_lead->AnnualPayroll6}}</td>
                        <td>{{$alldata_lead->noofEE6}}</td>
                           
                      </tr>
                      <tr>
                         <td>{{$alldata_lead->JobDescription7}}</td>
                        <td>{{$alldata_lead->ClassCode7}}</td>
                        <td>{{$alldata_lead->Rate100_7}}</td>
                        <td>{{$alldata_lead->AnnualPayroll7}}</td>
                        <td>{{$alldata_lead->noofEE7}}</td>
                           
                      </tr>
                      
                      <tr>
                            <td></td>
                            <td></td>
                            <td>Total</td>
                            <td>000000</td>
                            <td>0000</td>
                           
                      </tr>
                    </tbody>
                  </table>
    </div>
    <div class="clearfix"></div>
</div>
<!------------------->
    <div class="row">
            <div class="form-group"> 
                <div class="col-md-4"> 
            <label for="contact">Payroll Frequency:  </label>  
      </div>
	  <div class="col-sm-3 col-md-3">
        {{$alldata_lead->PayrollFrequency}}
    </div>
    </div>
    </div>

    <div class="row">
            <div class="form-group"> 
                    <div class="col-md-4"> 
                    <label for="contact">Current Cost of Payroll:  </label>  
      </div>
    <div class="col-sm-3 col-md-3">
        {{$alldata_lead->CurrentCostPayroll}}
    </div>
<div class="col-sm-5 col-md-5">
(payroll service, internal costs, etc…)
</div>
    </div>
    </div>


    <div class="row">
            <div class="form-group"> 
                <div class="col-md-4"> 
            <label for="contact">Current Cost of HR:  </label>  
      </div>
      <div class="col-sm-3 col-md-3">
            {{$alldata_lead->CurrentofHR}}
        </div>
    <div class="col-sm-5 col-md-5">
            (PEO, HR consulting, internal costs, etc…)
    </div>
    </div>
    </div>

    <div class="row">
            <div class="form-group"> 
                <div class="col-md-5"> 
            <label for="contact">Current State Unemployment Rate:  </label>  
      </div>
      <div class="col-sm-3 col-md-3">
            {{$alldata_lead->CurrentStateUnemployment}}
        </div>
    </div>
    </div>

    <div class="row">
            <div class="form-group"> 
                <div class="col-md-5"> 
            <label for="contact">Workers Compensation Modifier:  </label>  
      </div>
      <div class="col-sm-3 col-md-3">
            {{$alldata_lead->WorkersCompensationModifier}}
        </div>
    </div>
    </div>

    <div class="row">
            <div class="form-group"> 
                <div class="col-md-5"> 
            <label for="contact">Desired Start Date  </label>  
      </div>
      <div class="col-sm-3 col-md-3">
            {{$alldata_lead->DesiredStartDate}}
        </div>
    </div>
    </div>

    <!---------- General Benefit Information: ------------>
    <div class="row">
            <div class="col-sm-12 col-md-12">
               <div class="form-group">
                 <strong>General Benefit Information:</strong><br />      
                 </div>
               </div>
    </div>

    <div class="row">
            <div class="form-group"> 
                <div class="col-md-7"> 
            <label for="contact">Does Employer Currently have Benefits?  </label>  
      </div>
      <div class="col-sm-3 col-md-3">
          {{$alldata_lead->EmployerCurrentlyBenefits}} 
        </div>
        <div class="col-sm-2 col-md-2">
           
            </div>
    </div>
    </div>

    <div class="row">
            <div class="form-group"> 
                <div class="col-md-7"> 
            <label for="contact">Does Employer Wish to Offer NetPEO HR Benefits?   </label>  
      </div>
      <div class="col-sm-3 col-md-3">
          {{$alldata_lead->NetPEOHRBenefits}} 
        </div>
        <div class="col-sm-2 col-md-2">
           
            </div>
    </div>
    </div>

    <div class="row">
            <div class="form-group"> 
                <div class="col-md-7"> 
            <label for="contact">Does Employer Currently have a 401(k)?  </label>  
      </div>
      <div class="col-sm-3 col-md-3">
           {{$alldata_lead->EmployerCurrently401}}
        </div>
        <div class="col-sm-2 col-md-2">
           
            </div>
    </div>
    </div>

    <div class="row">
            <div class="form-group"> 
                <div class="col-md-7"> 
            <label for="contact">Does Employer Wish to Offer NetPEO HR 401(k)?  </label>  
      </div>
      <div class="col-sm-3 col-md-3">
          {{$alldata_lead->NetPEOHR401}} 
        </div>
        <div class="col-sm-2 col-md-2">
           
            </div>
    </div>
    </div>


<!--------------------  end  --------------->


<!-------------------- WORKERS COMPENSATION APPLICATION  ------------------------------>
<div class="workers">
<div class="row">
        <div class="col-sm-12 col-md-12">     
                <div class="breadcrum">     
             <h4>WORKERS COMPENSATION APPLICATION</h4>  
             </div>              
    </div>
</div>

    <div class="row">
            <div class="col-sm-6 col-md-6">
                <table class="table table-bordered table-responsive">
                    <thead>
                        <th colspan="4">AGENCY NAME AND ADDRESS </th>
                    </thead>
                    <tbody>
                            <tr>
                            <td colspan="4">{{$alldata_lead->acc_agency_and_address}} </td>
                      </tr>
                          <tr>
                            <td>PRODUCER NAME:</td>
                            <td colspan="3">{{$alldata_lead->acc_producer_name}} </td>
                           
                          </tr>

                          <tr>
                            <td>CS REPRESENTATIVE Name:</td>
                            <td colspan="3">{{$alldata_lead->acc_repersantive_name}} </td>
                         
                          </tr>

                          <tr>
                                <td>OFFICE PHONE
                                        (A/C, No, Ext):</td>
                                <td colspan="3">{{$alldata_lead->acc_agency_office_name}} </td>                             
                              </tr>

                              <tr>
                                    <td>MOBILE
                                            PHONE:</td>
                                    <td colspan="3">{{$alldata_lead->acc_agency_mobile_name}} </td>                             
                                  </tr>

                                  <tr>
                                    <td>FAX
                                        (A/C, No):</td>
                                        <td colspan="3">{{$alldata_lead->acc_agency_fax_no}} </td>                             
                                      </tr>

                                      <tr>
                                      <td>E-Mail Address</td>
                                    <td colspan="3">{{$alldata_lead->acc_agency_email}} </td>                             
                                 </tr>

                                 <tr>
                                        <td>CODE:</td>
                                      <td>{{$alldata_lead->acc_agency_code}}</td>  
                                      <td>SUB CODE:</td>
                                      <td>{{$alldata_lead->acc_agency_sub_code}}</td>                            
                                   </tr>
                                   
                   </tbody>
            </table>
      </div>

 <div class="col-sm-6 col-md-6">
            <table class="table table-bordered table-responsive">
                    <tbody>
                      <tr>
                        <td>COMPANY:</td>
                        <td colspan="4">{{$alldata_lead->acc_company}}</td>
                       
                      </tr>

                      <tr>
                        <td>UNDERWRITER:</td>
                        <td colspan="4">{{$alldata_lead->acc_underwriter}}</td>                     
                      </tr>
                      <tr>
                            <td>APPLICANT NAME:</td>
                            <td colspan="4">{{$alldata_lead->acc_applicant_name}}</td>                             
                          </tr>

                                <tr>
                                <td>OFFICE PHONE:</td>
                                <td>{{$alldata_lead->acc_office_phone}}</td>  
                                <td colspan="2">MOBILE PHONE:</td>
                                <td>{{$alldata_lead->acc_mobile_phone}}</td>                            
                              </tr>

                              <tr>
                                <td rowspan="4" colspan="2">MAILING ADDRESS (including ZIP + 4 or Canadian Postal Code): {{$alldata_lead->acc_agency_sub_code}}</td>                           
                                    <td colspan="3">YRS IN BUS: {{$alldata_lead->acc_yrs_in_bus}}</td> 											
                                </tr>

                                  <tr>
                                  <td>SIC:</td> 
								<td colspan="2">{{$alldata_lead->acc_sic}}</td>								  
                             </tr>

                             <tr>
                                <td>NAICS:</td> 
								<td colspan="2"> {{$alldata_lead->acc_naics}}</td>								
                               </tr>

                               <tr>
                                <td>Website Address</td>    
								<td colspan="2">{{$alldata_lead->acc_web_adderss}}</td>									
                               </tr>

							   <tr>
							   <td colspan="5">E-MAIL ADDRESS: {{$alldata_lead->acc_company_email_address}}</td>
							   </tr>

                               <tr>
                               <td></td>
                                <td></td>
                                 <td></td>
                                  <td></td>
                                   <td></td>
                               </tr>

                               <tr>
                               <td colspan="2">CREDIT BUREAU NAME:</td>
                                <td>{{$alldata_lead->acc_company_credit_bureau_name}}</td>
                                 <td>ID NUMBER:</td>
                                   <td>{{$alldata_lead->acc_company_id_number}}</td>
                              </tr>

                               <tr>
                                <td colspan="2">FEDERAL EMPLOYER ID NUMBER:  {{$alldata_lead->acc_fedral_no}}</td>  
                                 <td>NCCI RISK ID NUMBER:   {{$alldata_lead->acc_ncci_risk_no}} </td> 
                                  <td colspan="2">OTHER RATING BUREAU ID OR STATE
                                        EMPLOYER REGISTRATION NUMBER  {{$alldata_lead->acc_other_bureau_id}}</td>                                                                
                                </tr>
                                <tr>
                                <td colspan="2"></td>  
                                 <td></td> 
                                  <td colspan="2"></td>                                                                
                                </tr>
                      </tbody>
                      </table>
  </div>
</div>


<!---------- STATUS OF SUBMISSION --------->
<div class="row">
    <div class="col-md-4">
        <div class="breadcrum">     
             <h4>STATUS OF SUBMISSION</h4>  
        </div>         
    </div>
    <div class="col-md-8">
        <div class="breadcrum">     
             <h4>BILLING / AUDIT INFORMATION</h4>  
        </div>         
    </div>
</div>

<div class="row">
        <div class="col-sm-4 col-md-4">
            <table class="table table-bordered table-responsive">
                    <tbody>
                      <tr>
                        <td>QUOTE</td>
                        <td>ISSUE POLICY</td>                      
                      </tr>

                      <tr>
                        <td colspan="2">BOUND (Give date and/or attach copy)</td>                     
                      </tr>

                      <tr>
                        <td colspan="2">ASSIGNED RISK (Attach ACORD 133)</td>                      
                      </tr>
                      
                      </tbody>
                  </table>
              </div>
        <div class="col-sm-8 col-md-8">
            <table class="table table-bordered table-responsive">
                <thead>
                    <tr>
                        <th>BILLING PLAN</th>
                        <th colspan="2">PAYMENT PLAN</th>
                        <th colspan="2">AUDIT</th>
                    </tr>
             </thead>
                    <tbody>
                      <tr>
                        <td>AGENCY BILL</td>
                        <td colspan="2">ANNUAL</td>  
                         <td>AT EXPIRATION</td>  
                          <td>MONTHLY</td>                    
                      </tr>

                      <tr>
                        <td>DIRECT BILL</td>
                        <td colspan="2">SEMI-ANNUAL</td>  
                         <td>SEMI-ANNUAL</td>  
                          <td></td>                    
                      </tr>
                      <tr>
                        <td></td>
                        <td>QUARTERLY</td> 
                        <td>% DOWN:</td> 
                         <td colspan="2">QUARTERLY</td>                                           
                      </tr>
                      
                      </tbody>
                  </table>
              </div>
          </div>

<!---------- LOCATIONS --------->
<div class="row">
    <div class="col-sm-12 col-md-12">
        <div class="breadcrum">     
             <h4>LOCATIONS</h4>  
        </div>         
    </div>
</div>

<div class="row">
    <div class="col-sm-12 col-md-12">
            <table class="table table-bordered table-responsive">
                    <thead>
                      <tr>
                        <th>LOC #</th>
                        <th>HIGHEST FLOOR</th>
                        <th>STREET, CITY, COUNTY, STATE, ZIP CODE</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td></td>
                        <td></td>
                        <td></td>                                         
                      </tr>
                      <tr>
                            <td></td>
                            <td></td>
                            <td></td>                                                     
                      </tr>
                      <tr>
                            <td></td>
                            <td></td>
                            <td></td>                                                    
                      </tr>
                    </tbody>
                  </table>
    </div>
    <div class="clearfix"></div>
</div>

<!---------- POLICY INFORMATION --------->
<div class="row">
    <div class="col-sm-12 col-md-12">
        <div class="breadcrum">     
             <h4>POLICY INFORMATION</h4>  
        </div>         
    </div>
</div>
<div class="row">
    <div class="col-sm-12 col-md-12">
            <table class="table table-bordered table-responsive">
                    <thead>
                      <tr>
                        <th>PROPOSED EFF DATE</th>
                        <th>PROPOSED EXP DATE</th>
                        <th> NORMAL ANNIVERSARY RATING DATE</th>
                         <th> PARTICIPATING</th>
                          <th colspan="4">RETRO PLAN</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td>NON-PARTICIPATING</td>
                        <td colspan="4"></td>                                         
                      </tr>
                    </tbody>
                    <thead>
                      <tr>
                        <th rowspan="3">PART 1 - WORKERS COMPENSATION (States)</th>
                        <th colspan="2">PART 2 - EMPLOYER'S LIABILITY</th>
                        <th> PART 3 - OTHER STATES INS</th>
                         <th>DEDUCTIBLES (N/A in WI) </th>
                          <th>AMOUNT / % (N/A in WI)</th>
                          <th colspan="2">OTHER COVERAGES</th>                        
                      </tr>
                    </thead>
                     <tbody>
                      <tr>
                        <td></td>
                        <td>$10000</td>
                         <td>EACH ACCIDENT</td> 
                         <td></td> 
                         <td>MEDICAl</td> 
                         <td></td> 
                         <td>U.S.L. & H.</td> 
                         <td>MANAGED CARE OPTION</td>                                     
                      </tr>
                      <tr>
                        <td></td>
                        <td>$10000</td>
                         <td>DISEASE-POLICY LIMIT</td> 
                         <td></td> 
                         <td>INDEMNITY</td> 
                         <td></td> 
                         <td>VOLUNTARY COMP</td> 
                         <td></td>                                     
                      </tr>
                       <tr>
                        <td></td>
                        <td>$10000</td>
                         <td>DISEASE-EACH EMPLOYEE</td> 
                         <td></td> 
                         <td></td> 
                         <td></td> 
                         <td>FOREIGN COV</td> 
                         <td></td>                                     
                      </tr>
                    </tbody>
                    <thead>
                      <tr>
                        <th colspan="2">DIVIDEND PLAN/SAFETY GROUP</th>
                        <th colspan="6">ADDITIONAL COMPANY INFORMATION</th>                     
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td colspan="2"></td>
                        <td colspan="6"></td>                                     
                      </tr>
                  </tbody>
                  <thead>
                      <tr>
                        <th colspan="8">SPECIFY ADDITIONAL COVERAGES / ENDORSEMENTS (Attach ACORD 101, Additional Remarks Schedule, if more space is required)</th>                                           
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td colspan="8"></td>                                   
                      </tr>
                  </tbody>
                  </table>
    </div>
    <div class="clearfix"></div>
</div>

<!---------- TOTAL ESTIMATED ANNUAL PREMIUM - ALL STATES --------->
<div class="row">
    <div class="col-md-12">
        <div class="breadcrum">     
             <h4>TOTAL ESTIMATED ANNUAL PREMIUM - ALL STATES</h4>  
        </div>         
    </div>
</div>
<div class="row">
    <div class="col-sm-12 col-md-12">
            <table class="table table-bordered table-responsive">
                    <thead>
                      <tr>
                        <th>TOTAL ESTIMATED ANNUAL PREMIUM ALL STATES</th>
                        <th>TOTAL MINIMUM PREMIUM ALL STATES</th>
                        <th>TOTAL DEPOSIT PREMIUM ALL STATES</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>$</td>
                        <td>$</td>
                        <td>$</td>                                        
                      </tr>
                    </tbody>
                  </table>
    </div>
    <div class="clearfix"></div>
</div>

<!---------- CONTACT INFORMATION--------->
<div class="row">
    <div class="col-md-12">
        <div class="breadcrum">     
             <h4>CONTACT INFORMATION</h4>  
        </div>         
    </div>
</div>
<div class="row">
    <div class="col-sm-12 col-md-12">
            <table class="table table-bordered table-responsive">
                    <thead>
                      <tr>
                        <th>TYPE</th>
                        <th>NAME</th>
                        <th>OFFICE PHONE</th>
                        <th>MOBILE PHONE</th>
                        <th>E-MAIL</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>INSPECTION</td>
                        <td></td>
                        <td></td> 
                        <td></td>
                        <td></td>                                        
                      </tr>
                      <tr>
                        <td>ACCTNG RECORD</td>
                        <td></td>
                        <td></td> 
                        <td></td>
                        <td></td>                                        
                      </tr>
                      <tr>
                        <td>CLAIMS INFO</td>
                        <td></td>
                        <td></td> 
                        <td></td>
                        <td></td>                                        
                      </tr>
                    </tbody>
                  </table>
    </div>
    <div class="clearfix"></div>
</div>

<!---------- INDIVIDUALS INCLUDED / EXCLUDED--------->
<div class="row">
    <div class="col-md-12">
        <div class="breadcrum">     
             <h4>INDIVIDUALS INCLUDED / EXCLUDED</h4>  
        </div>         
    </div>
</div>
<div class="row">
    <div class="col-sm-12 col-md-12">
            <table class="table table-bordered table-responsive">
                    <thead>
                      <tr>
                        <th colspan="10">PARTNERS, OFFICERS, RELATIVES ( Must be employed by business operations) TO BE INCLUDED OR EXCLUDED (Remuneration/Payroll to be included must be part of rating information section.)
Exclusions in Missouri must meet the requirements of Section 287.090 RSMo. </th>                       
                      </tr>
                    </thead>
                     <thead>
                      <tr>
                        <th>STATE</th>
                        <th>LOC #</th>
                        <th>NAME</th>
                        <th>DATE OF BIRTH</th>
                        <th>TITLE/ RELATIONSHIP</th>
                        <th>OWNER- STATE LOC # SHIP %</th>
                        <th>DUTIES</th>
                        <th>INC/EXC</th>
                        <th>CLASS CODE</th>
                        <th>REMUNERATION/PAYROLL</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td></td>
                        <td></td>
                        <td></td> 
                        <td></td>
                        <td></td> 
                         <td></td>
                        <td></td>
                        <td></td> 
                        <td></td>
                        <td></td>                                          
                      </tr>
                      <tr>
                        <td></td>
                        <td></td>
                        <td></td> 
                        <td></td>
                        <td></td> 
                         <td></td>
                        <td></td>
                        <td></td> 
                        <td></td>
                        <td></td>                                          
                      </tr>
                      <tr>
                        <td></td>
                        <td></td>
                        <td></td> 
                        <td></td>
                        <td></td>
                         <td></td>
                        <td></td>
                        <td></td> 
                        <td></td>
                        <td></td>                                           
                      </tr>
                      <tr>
                        <td></td>
                        <td></td>
                        <td></td> 
                        <td></td>
                        <td></td>  
                         <td></td>
                        <td></td>
                        <td></td> 
                        <td></td>
                        <td></td>                                         
                      </tr>
                    </tbody>
                  </table>
    </div>
    <div class="clearfix"></div>
</div>

<!---------- STATE RATING WORKSHEET--------->
<div class="row">
    <div class="col-md-12">
        <div class="breadcrum">     
            <h4 style="text-align: center;">STATE RATING WORKSHEET</h4>
                  <h4>FOR MULTIPLE STATES, ATTACH AN ADDITIONAL PAGE 2 OF THIS FORM</h4>
                   <h4>RATING INFORMATION - STATE:</h4> 
        </div>         
    </div>
</div>
<div class="row">
    <div class="col-sm-12 col-md-12">
            <table class="table table-bordered table-responsive">
                     <thead>
                      <tr>
                        <th>LOC #</th>
                        <th>CLASS CODE</th>
                        <th>DESCR CODE</th>
                        <th>CATEGORIES, DUTIES, CLASSIFICATIONS</th>
                        <th colspan="2"># EMPLOYEES</th>
                        <th>SIC</th>
                        <th>NAICS</th>
                        <th>ESTIMATED ANNUAL REMUNERATION/ PAYROLL</th>
                        <th>RATE</th>
                        <th colspan="2">ESTIMATED ANNUAL MANUAL PREMIUM</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td></td>
                        <td></td>
                        <td></td> 
                        <td></td>
                        <td></td> 
                         <td></td>
                        <td></td>
                        <td></td> 
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>                                           
                      </tr>
                      <tr>
                        <td></td>
                        <td></td>
                        <td></td> 
                        <td></td>
                        <td></td> 
                         <td></td>
                        <td></td>
                        <td></td> 
                        <td></td>
                        <td></td> 
                        <td></td>
                        <td></td>                                          
                      </tr>
                      <tr>
                        <td></td>
                        <td></td>
                        <td></td> 
                        <td></td>
                        <td></td>
                         <td></td>
                        <td></td>
                        <td></td> 
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>                                            
                      </tr>
                      <tr>
                        <td></td>
                        <td></td>
                        <td></td> 
                        <td></td>
                        <td></td>  
                         <td></td>
                        <td></td>
                        <td></td> 
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>                                          
                      </tr>
                      <tr>
                        <td></td>
                        <td></td>
                        <td></td> 
                        <td></td>
                        <td></td> 
                         <td></td>
                        <td></td>
                        <td></td> 
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>                                           
                      </tr>
                      <tr>
                        <td></td>
                        <td></td>
                        <td></td> 
                        <td></td>
                        <td></td> 
                         <td></td>
                        <td></td>
                        <td></td> 
                        <td></td>
                        <td></td> 
                        <td></td>
                        <td></td>                                          
                      </tr>
                      <tr>
                        <td></td>
                        <td></td>
                        <td></td> 
                        <td></td>
                        <td></td> 
                         <td></td>
                        <td></td>
                        <td></td> 
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>                                           
                      </tr>
                      <tr>
                        <td></td>
                        <td></td>
                        <td></td> 
                        <td></td>
                        <td></td> 
                         <td></td>
                        <td></td>
                        <td></td> 
                        <td></td>
                        <td></td> 
                        <td></td>
                        <td></td>                                          
                      </tr>
                      <tr>
                        <td></td>
                        <td></td>
                        <td></td> 
                        <td></td>
                        <td></td> 
                         <td></td>
                        <td></td>
                        <td></td> 
                        <td></td>
                        <td></td>                                          
                        <td></td>
                        <td></td> 
                      </tr>
                      <tr>
                        <td></td>
                        <td></td>
                        <td></td> 
                        <td></td>
                        <td></td> 
                         <td></td>
                        <td></td>
                        <td></td> 
                        <td></td>
                        <td></td> 
                        <td></td>
                        <td></td>                                          
                      </tr>
                      <tr>
                        <td></td>
                        <td></td>
                        <td></td> 
                        <td></td>
                        <td></td> 
                         <td></td>
                        <td></td>
                        <td></td> 
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>                                           
                      </tr>
                      <tr>
                        <td></td>
                        <td></td>
                        <td></td> 
                        <td></td>
                        <td></td> 
                         <td></td>
                        <td></td>
                        <td></td> 
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>                                           
                      </tr>
                      <tr>
                        <td></td>
                        <td></td>
                        <td></td> 
                        <td></td>
                        <td></td> 
                         <td></td>
                        <td></td>
                        <td></td> 
                        <td></td>
                        <td></td> 
                        <td></td>
                        <td></td>                                          
                      </tr>
                      <tr>
                        <td></td>
                        <td></td>
                        <td></td> 
                        <td></td>
                        <td></td> 
                         <td></td>
                        <td></td>
                        <td></td> 
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>                                           
                      </tr>
                    </tbody>
                  </table>
    </div>
    <div class="clearfix"></div>
</div>


<!---------- PREMIUM --------->
<div class="row">
    <div class="col-md-12">
        <div class="breadcrum">     
            <h4>PREMIUM</h4>
        </div>         
    </div>
</div>
<div class="row">
    <div class="col-sm-12 col-md-12">
            <table class="table table-bordered table-responsive">
                     <thead>
                      <tr>
                        <th>STATE:</th>
                        <th>FACTOR</th>
                        <th>FACTORED PREMIUM</th>
                        <th></th>
                        <th>FACTOR</th>
                        <th>FACTORED PREMIUM</th>
                      </tr>
                    </thead>
                    <tbody>
                        <tr>
                        <td>TOTAL</td> 
                        <td>N / A</td>
                        <td>$</td>
                        <td></td>
                        <td></td> 
                        <td>$</td> 
                        </tr>
                        <tr>
                        <td>INCREASED LIMITS</td> 
                        <td></td>
                        <td>$</td>
                        <td>SCHEDULE RATING *</td>
                        <td></td> 
                        <td>$</td> 
                        </tr>
                        <tr>
                        <td>DEDUCTIBLE *</td> 
                        <td></td>
                        <td>$</td>
                        <td>CCPAP</td>
                        <td></td>
                        <td>$</td>  
                        </tr>
                        <tr>
                        <td></td> 
                        <td></td>
                        <td>$</td>
                        <td>STANDARD PREMIUM</td>
                        <td></td> 
                        <td>$</td> 
                        </tr>
                        <tr>
                        <td>EXPERIENCE OR MERIT</td> 
                        <td></td>
                        <td>$</td>
                        <td>PREMIUM DISCOUNT</td>
                        <td></td> 
                        <td>$</td> 
                        </tr>
                        <tr>
                        <td></td> 
                        <td></td>
                        <td>$</td>
                        <td>EXPENSE CONSTANT</td>
                        <td>N / A</td>
                        <td>$</td>  
                        </tr>
                        <tr>
                        <td>ASSIGNED RISK SURCHARGE *</td> 
                        <td></td>
                        <td>$</td>
                        <td>TAXES / ASSESSMENTS *</td>
                        <td>N / A</td>
                        <td>$</td>  
                        </tr>
                        <tr>
                        <td>ARAP *</td> 
                        <td></td>
                        <td>$</td>
                        <td></td>
                        <td></td>
                        <td>$</td>  
                        </tr>
                         <tr>
                        <td colspan="6">* N / A in Wisconsin</td>   
                        </tr>
                        </tbody>
                        <thead>
                      <tr>
                        <th colspan="2">TOTAL ESTIMATED ANNUAL PREMIUM</th>
                        <th colspan="2">MINIMUM PREMIUM</th>
                        <th colspan="2">DEPOSIT PREMIUM</th>
                      </tr>
                    </thead>
                    <tbody>
                        <td colspan="2">$</td>
                        <td colspan="2">$</td>
                        <td colspan="2">$</td>                       
                    </tbody>
                    </table>
                </div>
            </div>

<!---------- REMARKS  --------->
<div class="row">
    <div class="col-md-12">
        <div class="breadcrum">     
            <h4>REMARKS (ACORD 101, Additional Remarks Schedule, may be attached if more space is required)</h4>
        </div>         
    </div>
</div>
<div class="row">
    <div class="col-sm-12 col-md-12">
            <table class="table table-bordered table-responsive">
                <tbody>
                    <tr>
                    <td></td>
                </tr>
                </tbody>
            </table>
        </div>
    </div>

<!---------- PRIOR CARRIER INFORMATION / LOSS HISTORY  --------->
<div class="row">
    <div class="col-md-6">
        <div class="breadcrum">     
            <h4>PRIOR CARRIER INFORMATION / LOSS HISTORY</h4>
        </div>         
    </div>
    <div class="col-md-6">
        <div class="breadcrum">     
            <h4>AGENCY CUSTOMER ID:</h4>
        </div>         
    </div>
</div>
<div class="row">
    <div class="col-sm-12 col-md-12">
            <table class="table table-bordered table-responsive">
                <thead>
                    <tr>
                        <th colspan="3">PROVIDE INFORMATION FOR THE PAST 5 YEARS AND USE THE REMARKS SECTION FOR LOSS DETAILS</th>
                         <th colspan="5">LOSS RUN ATTACHED</th>
                      </tr>
                      <tr>
                        <th>YEAR</th>
                        <th>CARRIER & POLICY NUMBER</th>
                        <th>ANNUAL PREMIUM</th>
                        <th>MOD</th>
                        <th># CLAIMS</th>
                        <th>AMOUNT PAID</th>
                        <th colspan="3">RESERVE</th>
                      </tr>
                </thead>
                <tbody>
                    <tr>
                    <td rowspan="2"></td>
                    <td>CO:</td>
                    <td rowspan="2"></td>
                    <td rowspan="2"></td>
                    <td rowspan="2"></td>
                    <td rowspan="2"></td>
                    <td rowspan="2"></td>
                </tr>
                <tr>
                    <td>POL #:</td>
                </tr>
                <tr>
                    <td rowspan="2"></td>
                    <td>CO:</td>
                    <td rowspan="2"></td>
                    <td rowspan="2"></td>
                    <td rowspan="2"></td>
                    <td rowspan="2"></td>
                    <td rowspan="2"></td>
                </tr>
                <tr>
                    <td>POL #:</td>
                </tr>
                <tr>
                    <td rowspan="2"></td>
                    <td>CO:</td>
                    <td rowspan="2"></td>
                    <td rowspan="2"></td>
                    <td rowspan="2"></td>
                    <td rowspan="2"></td>
                    <td rowspan="2"></td>
                </tr>
                <tr>
                    <td>POL #:</td>
                </tr>
                <tr>
                    <td rowspan="2"></td>
                    <td>CO:</td>
                    <td rowspan="2"></td>
                    <td rowspan="2"></td>
                    <td rowspan="2"></td>
                    <td rowspan="2"></td>
                    <td rowspan="2"></td>
                </tr>
                <tr>
                    <td>POL #:</td>
                </tr>
                <tr>
                    <td rowspan="2"></td>
                    <td>CO:</td>
                    <td rowspan="2"></td>
                    <td rowspan="2"></td>
                    <td rowspan="2"></td>
                    <td rowspan="2"></td>
                    <td rowspan="2"></td>
                </tr>
                <tr>
                    <td>POL #:</td>
                </tr>

                </tbody>
            </table>
        </div>
    </div>

<!---------- NATURE OF BUSINESS / DESCRIPTION OF OPERATIONS  --------->
<div class="row">
    <div class="col-sm-12 col-md-12">
        <div class="breadcrum">     
            <h4>NATURE OF BUSINESS / DESCRIPTION OF OPERATIONS</h4>
        </div>         
    </div>
</div>
<div class="row">
    <div class="col-sm-12 col-md-12">
            <table class="table table-bordered table-responsive">
                <thead>
                    <tr>
                        <th colspan="3">GIVE COMMENTS AND DESCRIPTIONS OF BUSINESS, OPERATIONS AND PRODUCTS: MANUFACTURING - RAW MATERIALS, PROCESSES, PRODUCT, EQUIPMENT; CONTRACTOR - TYPE OF WORK, SUB-CONTRACTS; MERCANTILE - MERCHANDISE, CUSTOMERS, DELIVERIES; SERVICE - TYPE, LOCATION; FARM - ACREAGE, ANIMALS, MACHINERY, SUB-CONTRACTS.
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td></td>
                    </tr>
                </tbody>
                </table>
            </div>
        </div>


<!---------- GENERAL INFORMATION  --------->
<div class="row">
    <div class="col-sm-12 col-md-12">
        <div class="breadcrum">     
            <h4>GENERAL INFORMATION</h4>
        </div>         
    </div>
</div>
<div class="row">
    <div class="col-sm-12 col-md-12">
            <table class="table table-bordered table-responsive">
                <thead>
                    <tr>
                        <th>EXPLAIN ALL "YES" RESPONSES</th>
                        <th>Y / N</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1. DOES APPLICANT OWN, OPERATE OR LEASE AIRCRAFT / WATERCRAFT?</td>
                        <td rowspan="2"></td>
                    </tr>
                    <tr>
                        <td></td>
                    </tr>
                    <tr>
                        <td>2. DO / HAVE PAST, PRESENT OR DISCONTINUED OPERATIONS INVOLVE(D) STORING, TREATING, DISCHARGING, APPLYING, DISPOSING, OR TRANSPORTING OF HAZARDOUS MATERIAL? (e.g. landfills, wastes, fuel tanks, etc)</td>
                        <td rowspan="2"></td>
                    </tr>
                    <tr>
                        <td></td>
                    </tr>
                    <tr>
                        <td>3. ANY WORK PERFORMED UNDERGROUND OR ABOVE 15 FEET?</td>
                        <td rowspan="2"></td>
                    </tr>
                    <tr>
                        <td></td>
                    </tr>
                    <tr>
                        <td>4. ANY WORK PERFORMED ON BARGES, VESSELS, DOCKS, BRIDGE OVER WATER?</td>
                        <td rowspan="2"></td>
                    </tr>
                    <tr>
                        <td></td>
                    </tr>
                    <tr>
                        <td>5. IS APPLICANT ENGAGED IN ANY OTHER TYPE OF BUSINESS?</td>
                        <td rowspan="2"></td>
                    </tr>
                    <tr>
                        <td></td>
                    </tr>
                    <tr>
                        <td>6. ARE SUB-CONTRACTORS USED? (If "YES", give % of work subcontracted)</td>
                        <td rowspan="2"></td>
                    </tr>
                    <tr>
                        <td></td>
                    </tr>
                    <tr>
                        <td>7. ANY WORK SUBLET WITHOUT CERTIFICATES OF INSURANCE? (If "YES", payroll for this work must be included in the State Rating Worksheet on Page 2)</td>
                        <td rowspan="2"></td>
                    </tr>
                    <tr>
                        <td></td>
                    </tr>
                    <tr>
                        <td>8. IS A WRITTEN SAFETY PROGRAM IN OPERATION?</td>
                        <td rowspan="2"></td>
                    </tr>
                    <tr>
                        <td></td>
                    </tr>
                    <tr>
                        <td>9. ANY GROUP TRANSPORTATION PROVIDED?</td>
                        <td rowspan="2"></td>
                    </tr>
                    <tr>
                        <td></td>
                    </tr>
                    <tr>
                        <td>10. ANY EMPLOYEES UNDER 16 OR OVER 60 YEARS OF AGE?</td>
                        <td rowspan="2"></td>
                    </tr>
                    <tr>
                        <td></td>
                    </tr>
                    <tr>
                        <td>11. ANY SEASONAL EMPLOYEES?</td>
                        <td rowspan="2"></td>
                    </tr>
                    <tr>
                        <td></td>
                    </tr>
                    <tr>
                        <td>12. IS THERE ANY VOLUNTEER OR DONATED LABOR? (If "YES", please specify)</td>
                        <td rowspan="2"></td>
                    </tr>
                    <tr>
                        <td></td>
                    </tr>
                    <tr>
                        <td>13. ANY EMPLOYEES WITH PHYSICAL HANDICAPS?</td>
                        <td rowspan="2"></td>
                    </tr>
                    <tr>
                        <td></td>
                    </tr>
                    <tr>
                        <td>14. DO EMPLOYEES TRAVEL OUT OF STATE? (If "YES", indicate state(s) of travel and frequency)</td>
                        <td rowspan="2"></td>
                    </tr>
                    <tr>
                        <td></td>
                    </tr>
                    <tr>
                        <td>15. ARE ATHLETIC TEAMS SPONSORED?</td>
                        <td rowspan="2"></td>
                    </tr>
                    <tr>
                        <td></td>
                    </tr>
                    <tr>
                        <td>16. ARE PHYSICALS REQUIRED AFTER OFFERS OF EMPLOYMENT ARE MADE?</td>
                        <td rowspan="2"></td>
                    </tr>
                    <tr>
                        <td></td>
                    </tr>
                    <tr>
                        <td>17. ANY OTHER INSURANCE WITH THIS INSURER?</td>
                        <td rowspan="2"></td>
                    </tr>
                    <tr>
                        <td></td>
                    </tr>
                    <tr>
                        <td>18. ANY PRIOR COVERAGE DECLINED / CANCELLED / NON-RENEWED IN THE LAST THREE (3) YEARS? (Missouri Applicants - Do not answer this question)</td>
                        <td rowspan="2"></td>
                    </tr>
                    <tr>
                        <td></td>
                    </tr>
                    <tr>
                        <td>19. ARE EMPLOYEE HEALTH PLANS PROVIDED?</td>
                        <td rowspan="2"></td>
                    </tr>
                    <tr>
                        <td></td>
                    </tr>
                    <tr>
                        <td>20. DO ANY EMPLOYEES PERFORM WORK FOR OTHER BUSINESSES OR SUBSIDIARIES?</td>
                        <td rowspan="2"></td>
                    </tr>
                    <tr>
                        <td></td>
                    </tr>
                    <tr>
                        <td>21. DO YOU LEASE EMPLOYEES TO OR FROM OTHER EMPLOYERS?</td>
                        <td rowspan="2"></td>
                    </tr>
                    <tr>
                        <td></td>
                    </tr>
                    <tr>
                        <td>22. DO ANY EMPLOYEES PREDOMINANTLY WORK AT HOME? If "YES", # of Employees:</td>
                        <td rowspan="2"></td>
                    </tr>
                    <tr>
                        <td></td>
                    </tr>
                    <tr>
                        <td>23. ANY TAX LIENS OR BANKRUPTCY WITHIN THE LAST FIVE (5) YEARS? (If "YES", please specify)</td>
                        <td rowspan="2"></td>
                    </tr>
                    <tr>
                        <td></td>
                    </tr>
                    <tr>
                        <td>24. ANY UNDISPUTED AND UNPAID WORKERS COMPENSATION PREMIUM DUE FROM YOU OR ANY COMMONLY MANAGED OR OWNED ENTERPRISES?
IF YES, EXPLAIN INCLUDING ENTITY NAME(S) AND POLICY NUMBER(S).</td>
                        <td rowspan="2"></td>
                    </tr>
                    <tr>
                        <td></td>
                    </tr>
                </tbody>
                </table>
            </div>
        </div>
        </div>
<!------------ End --------------------->
		

				<div class="form-group">
				<button class="btn btn-block btn-primary" type="submit" onclick="window.history.go(-1); return false;"><i class="si si-login pull-right"></i> Back</button>
			</div> 
		
	</div>
                                    </div>
                                    
                                </div>
                            </div>
                            <!-- END Block Tabs Alternative Style -->
                        </div>
                        
                    </div>
                </div>
                <!-- END Page Content -->
@endsection